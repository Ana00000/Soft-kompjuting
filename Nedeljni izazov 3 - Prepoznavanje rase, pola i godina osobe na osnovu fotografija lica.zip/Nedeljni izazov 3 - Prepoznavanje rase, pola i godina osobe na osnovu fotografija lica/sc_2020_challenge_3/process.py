import numpy as np
import cv2 as cv
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from joblib import dump
import os
import dlib
from imutils import face_utils


# Kod uzet sa vezbi

def train_or_load_age_model(train_image_paths, train_image_labels):
    """
    Procedura prima listu putanja do fotografija za obucavanje (dataset se sastoji iz razlicitih fotografija), liste
    labela za svaku fotografiju iz prethodne liste, kao i putanju do foldera u koji treba sacuvati model nakon sto se
    istrenira (da ne trenirate svaki put iznova)

    Procedura treba da istrenira model i da ga sacuva u folder "serialization_folder" pod proizvoljnim nazivom

    Kada se procedura pozove, ona treba da trenira model ako on nije istraniran, ili da ga samo ucita ako je prethodno
    istreniran i ako se nalazi u folderu za serijalizaciju

    :param train_image_paths: putanje do fotografija za obucavanje
    :param train_image_labels: labele za sve fotografije iz liste putanja za obucavanje
    :return: Objekat modela
    """
    # TODO - Istrenirati model ako vec nije istreniran, ili ga samo ucitati iz foldera za serijalizaciju
    X = []
    for train_image_path in train_image_paths:
        image = cv.imread(train_image_path)
        image = cv.cvtColor(image, cv.COLOR_BGR2RGB)
        gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

        nbr_bins = 7
        cell_size = (10, 10)
        block_size = (1, 1)

        hog = cv.HOGDescriptor(_winSize=(gray.shape[1] // cell_size[1] * cell_size[1],
                                         gray.shape[0] // cell_size[0] * cell_size[0]),
                               _blockSize=(block_size[1] * cell_size[1],
                                           block_size[0] * cell_size[0]),
                               _blockStride=(cell_size[1], cell_size[0]),
                               _cellSize=(cell_size[1], cell_size[0]),
                               _nbins=nbr_bins)

        X.append(hog.compute(gray))

    X = np.array(X)
    Y = np.array(train_image_labels)

    x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.29, random_state=50)
    x_train = reshape_data(x_train)

    if not os.path.exists('serialization_folder'):
        os.makedirs('serialization_folder')

    clf_svm = SVC(kernel='linear', probability=True)
    clf_svm.fit(x_train, y_train)
    dump(clf_svm, 'serialization_folder\\age_model.joblib')

    return clf_svm


def train_or_load_gender_model(train_image_paths, train_image_labels):
    """
    Procedura prima listu putanja do fotografija za obucavanje (dataset se sastoji iz razlicitih fotografija), liste
    labela za svaku fotografiju iz prethodne liste, kao i putanju do foldera u koji treba sacuvati model nakon sto se
    istrenira (da ne trenirate svaki put iznova)

    Procedura treba da istrenira model i da ga sacuva u folder "serialization_folder" pod proizvoljnim nazivom

    Kada se procedura pozove, ona treba da trenira model ako on nije istraniran, ili da ga samo ucita ako je prethodno
    istreniran i ako se nalazi u folderu za serijalizaciju

    :param train_image_paths: putanje do fotografija za obucavanje
    :param train_image_labels: labele za sve fotografije iz liste putanja za obucavanje
    :return: Objekat modela
    """
    # TODO - Istrenirati model ako vec nije istreniran, ili ga samo ucitati iz foldera za serijalizaciju
    X = []
    for train_image_path in train_image_paths:
        image = cv.imread(train_image_path)
        image = cv.cvtColor(image, cv.COLOR_BGR2RGB)
        gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

        nbr_bins = 8
        cell_size = (21, 21)
        block_size = (3, 3)

        hog = cv.HOGDescriptor(_winSize=(gray.shape[1] // cell_size[1] * cell_size[1],
                                         gray.shape[0] // cell_size[0] * cell_size[0]),
                               _blockSize=(block_size[1] * cell_size[1],
                                           block_size[0] * cell_size[0]),
                               _blockStride=(cell_size[1], cell_size[0]),
                               _cellSize=(cell_size[1], cell_size[0]),
                               _nbins=nbr_bins)

        X.append(hog.compute(gray))

    X = np.array(X)
    Y = np.array(train_image_labels)

    x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.21, random_state=49)
    x_train = reshape_data(x_train)

    if not os.path.exists('serialization_folder'):
        os.makedirs('serialization_folder')

    clf_svm = SVC(kernel='linear', probability=True)
    clf_svm.fit(x_train, y_train)
    dump(clf_svm, 'serialization_folder\\gender_model.joblib')

    return clf_svm


def train_or_load_race_model(train_image_paths, train_image_labels):
    """
    Procedura prima listu putanja do fotografija za obucavanje (dataset se sastoji iz razlicitih fotografija), liste
    labela za svaku fotografiju iz prethodne liste, kao i putanju do foldera u koji treba sacuvati model nakon sto se
    istrenira (da ne trenirate svaki put iznova)

    Procedura treba da istrenira model i da ga sacuva u folder "serialization_folder" pod proizvoljnim nazivom

    Kada se procedura pozove, ona treba da trenira model ako on nije istraniran, ili da ga samo ucita ako je prethodno
    istreniran i ako se nalazi u folderu za serijalizaciju

    :param train_image_paths: putanje do fotografija za obucavanje
    :param train_image_labels: labele za sve fotografije iz liste putanja za obucavanje
    :return: Objekat modela
    """
    # TODO - Istrenirati model ako vec nije istreniran, ili ga samo ucitati iz foldera za serijalizaciju
    X = []
    for train_image_path in train_image_paths:
        image = cv.imread(train_image_path)
        image = cv.cvtColor(image, cv.COLOR_BGR2RGB)
        gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

        nbr_bins = 7
        cell_size = (5, 5)
        block_size = (5, 5)

        hog = cv.HOGDescriptor(_winSize=(gray.shape[1] // cell_size[1] * cell_size[1],
                                         gray.shape[0] // cell_size[0] * cell_size[0]),
                               _blockSize=(block_size[1] * cell_size[1],
                                           block_size[0] * cell_size[0]),
                               _blockStride=(cell_size[1], cell_size[0]),
                               _cellSize=(cell_size[1], cell_size[0]),
                               _nbins=nbr_bins)

        X.append(hog.compute(gray))

    X = np.array(X)
    Y = np.array(train_image_labels)

    x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.05, random_state=51)
    x_train = reshape_data(x_train)

    if not os.path.exists('serialization_folder'):
        os.makedirs('serialization_folder')

    clf_svm = SVC(kernel='linear', probability=True)
    clf_svm.fit(x_train, y_train)
    dump(clf_svm, 'serialization_folder\\race_model.joblib')

    return clf_svm


def predict_age(trained_model, image_path):
    """
    Procedura prima objekat istreniranog modela za prepoznavanje godina i putanju do fotografije na kojoj
    se nalazi novo lice sa koga treba prepoznati godine.

    Ova procedura se poziva automatski iz main procedure pa nema potrebe dodavati njen poziv u main.py

    :param trained_model: <Model> Istrenirani model za prepoznavanje godina
    :param image_path: <String> Putanja do fotografije sa koje treba prepoznati godine lica
    :return: <Int> Prediktovanu vrednost za goinde  od 0 do 116
    """
    # TODO - Prepoznati ekspresiju lica i vratiti njen naziv (kao string, iz skupa mogucih vrednosti)
    image = cv.imread(image_path)
    image = cv.cvtColor(image, cv.COLOR_BGR2RGB)
    gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

    nbr_bins = 7
    cell_size = (10, 10)
    block_size = (1, 1)

    detector = dlib.get_frontal_face_detector()
    rectangles = detector(gray, 2)

    resized_img = cv.resize(gray, (200, 200), interpolation=cv.INTER_AREA)

    for (i, rect) in enumerate(rectangles):
        (x, y, w, h) = face_utils.rect_to_bb(rect)
        img = cv.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
        crop_img = img[y:y + h, x:x + w]
        gray = cv.cvtColor(crop_img, cv.COLOR_BGR2GRAY)
        crop_img = cv.resize(gray, (200, 200), interpolation=cv.INTER_AREA)
        resized_img = crop_img

    hog = cv.HOGDescriptor(_winSize=(resized_img.shape[1] // cell_size[1] * cell_size[1],
                                     resized_img.shape[0] // cell_size[0] * cell_size[0]),
                           _blockSize=(block_size[1] * cell_size[1],
                                       block_size[0] * cell_size[0]),
                           _blockStride=(cell_size[1], cell_size[0]),
                           _cellSize=(cell_size[1], cell_size[0]),
                           _nbins=nbr_bins)

    x = [hog.compute(resized_img)]
    x = np.array(x)
    x = reshape_data(x)
    age = int(trained_model.predict(x))

    return age


def predict_gender(trained_model, image_path):
    """
    Procedura prima objekat istreniranog modela za prepoznavanje pola na osnovu lica i putanju do fotografije na kojoj
    se nalazi novo lice sa koga treba prepoznati pol.

    Ova procedura se poziva automatski iz main procedure pa nema potrebe dodavati njen poziv u main.py

    :param trained_model: <Model> Istrenirani model za prepoznavanje karaktera
    :param image_path: <String> Putanja do fotografije sa koje treba prepoznati ekspresiju lica
    :return: <Int>  Prepoznata klasa pola (0 - musko, 1 - zensko)
    """
    # TODO - Prepoznati ekspresiju lica i vratiti njen naziv (kao string, iz skupa mogucih vrednosti)
    image = cv.imread(image_path)
    image = cv.cvtColor(image, cv.COLOR_BGR2RGB)
    gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

    nbr_bins = 8
    cell_size = (21, 21)
    block_size = (3, 3)

    detector = dlib.get_frontal_face_detector()
    rectangles = detector(gray, 2)

    resized_img = cv.resize(gray, (200, 200), interpolation=cv.INTER_AREA)

    for (i, rect) in enumerate(rectangles):
        (x, y, w, h) = face_utils.rect_to_bb(rect)
        img = cv.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
        crop_img = img[y:y + h, x:x + w]
        gray = cv.cvtColor(crop_img, cv.COLOR_BGR2GRAY)
        crop_img = cv.resize(gray, (200, 200), interpolation=cv.INTER_AREA)
        resized_img = crop_img

    hog = cv.HOGDescriptor(_winSize=(resized_img.shape[1] // cell_size[1] * cell_size[1],
                                     resized_img.shape[0] // cell_size[0] * cell_size[0]),
                           _blockSize=(block_size[1] * cell_size[1],
                                       block_size[0] * cell_size[0]),
                           _blockStride=(cell_size[1], cell_size[0]),
                           _cellSize=(cell_size[1], cell_size[0]),
                           _nbins=nbr_bins)

    x = [hog.compute(resized_img)]
    x = np.array(x)
    x = reshape_data(x)
    gender = int(trained_model.predict(x))

    return gender


def predict_race(trained_model, image_path):
    """
    Procedura prima objekat istreniranog modela za prepoznavanje rase lica i putanju do fotografije na kojoj
    se nalazi novo lice sa koga treba prepoznati rasu.

    Ova procedura se poziva automatski iz main procedure pa nema potrebe dodavati njen poziv u main.py

    :param trained_model: <Model> Istrenirani model za prepoznavanje karaktera
    :param image_path: <String> Putanja do fotografije sa koje treba prepoznati ekspresiju lica
    :return: <Int>  Prepoznata klasa (0 - Bela, 1 - Crna, 2 - Azijati, 3- Indijci, 4 - Ostali)
    """
    # TODO - Prepoznati ekspresiju lica i vratiti njen naziv (kao string, iz skupa mogucih vrednosti)
    image = cv.imread(image_path)
    image = cv.cvtColor(image, cv.COLOR_BGR2RGB)
    gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

    nbr_bins = 7
    cell_size = (5, 5)
    block_size = (5, 5)

    detector = dlib.get_frontal_face_detector()
    rectangles = detector(gray, 2)

    resized_img = cv.resize(gray, (200, 200), interpolation=cv.INTER_AREA)

    for (i, rect) in enumerate(rectangles):
        (x, y, w, h) = face_utils.rect_to_bb(rect)
        img = cv.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
        crop_img = img[y:y + h, x:x + w]
        gray = cv.cvtColor(crop_img, cv.COLOR_BGR2GRAY)
        crop_img = cv.resize(gray, (200, 200), interpolation=cv.INTER_AREA)
        resized_img = crop_img

    hog = cv.HOGDescriptor(_winSize=(resized_img.shape[1] // cell_size[1] * cell_size[1],
                                     resized_img.shape[0] // cell_size[0] * cell_size[0]),
                           _blockSize=(block_size[1] * cell_size[1],
                                       block_size[0] * cell_size[0]),
                           _blockStride=(cell_size[1], cell_size[0]),
                           _cellSize=(cell_size[1], cell_size[0]),
                           _nbins=nbr_bins)

    x = [hog.compute(resized_img)]
    x = np.array(x)
    x = reshape_data(x)
    race = int(trained_model.predict(x))

    return race


def reshape_data(input_data):
    n_samples, nx, ny = input_data.shape
    return input_data.reshape((n_samples, nx * ny))
